document.addEventListener("DOMContentLoaded", function() {
  const forms = [
    document.querySelector(".moving"),
    document.getElementById("bedroom-form"),
    document.getElementById("details-form")
  ];
  
  const prevBtn = document.querySelector("button[type='previos']");
  const nextBtn = document.querySelector("button[type='next']");
  
  let currentStep = 0;

  // Hide all forms except the first one
  forms.forEach((form, index) => {
    form.style.display = index === 0 ? "block" : "none";
  });
  
  prevBtn.disabled = true; // Disable "Previous" at start

  function updateForm() {
    forms.forEach((form, index) => {
      form.style.display = index === currentStep ? "block" : "none";
    });

    // Control button states
    prevBtn.disabled = currentStep === 0;
    nextBtn.textContent = currentStep === forms.length - 1 ? "Submit" : "Next";
  }

  nextBtn.addEventListener("click", function() {
    if (currentStep < forms.length - 1) {
      currentStep++;
      updateForm();
    } else {
      alert("Form submitted!"); 
      // here you could handle actual form submission
    }
  });

  prevBtn.addEventListener("click", function() {
    if (currentStep > 0) {
      currentStep--;
      updateForm();
    }
  });
});

 document.addEventListener("DOMContentLoaded", function () {
      const form = document.getElementById("tracking-form");
      const input = document.getElementById("trackingInput");
      const resultBox = document.getElementById("trackingResult");

      form.addEventListener("submit", function (e) {
        e.preventDefault();
        const trackingID = input.value.trim();

        // Simulated tracking logic
        if (trackingID === "OPTIMOVE123") {
          resultBox.innerHTML = `
            <h3>Status: In Transit 🚚</h3>
            <p><strong>Pickup:</strong> Nairobi CBD<br>
               <strong>Destination:</strong> Karen<br>
               <strong>Estimated Delivery:</strong> 24 Aug 2025, 6:00 PM</p>
          `;
        } else {
          resultBox.innerHTML = `<p style="color:red;">Tracking ID not found. Please check and try again.</p>`;
        }
      });
    });