// OptiMove Smartlogistics AI - JavaScript Functionality

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lucide icons
    lucide.createIcons();
    
    // Initialize navigation
    initNavigation();
    
    // Initialize newsletter
    initNewsletter();
    
    // Initialize accessibility widget
    initAccessibilityWidget();
    
    // Initialize page routing
    initPageRouting();
});

// ...existing code...

document.addEventListener('DOMContentLoaded', function () {
  const accessibilityBtn = document.querySelector('.accessibility-btn');
  const accessibilityPanel = document.querySelector('.accessibility-panel');
  const closeBtn = document.querySelector('.close-accessibility');
  const highContrastBtn = document.querySelector('.option-btn');
  const decreaseFontBtn = document.getElementById('decrease-font');
  const increaseFontBtn = document.getElementById('increase-font');
  const fontSizeDisplay = document.getElementById('font-size-display');
  let fontSize = 100;
  let highContrastEnabled = false;

  // Show panel
  accessibilityBtn.addEventListener('click', () => {
    accessibilityPanel.style.display = 'block';
  });

  // Hide panel
  closeBtn.addEventListener('click', () => {
    accessibilityPanel.style.display = 'none';
  });

  // High Contrast toggle
  highContrastBtn.addEventListener('click', () => {
    highContrastEnabled = !highContrastEnabled;
    document.body.classList.toggle('high-contrast', highContrastEnabled);
    highContrastBtn.textContent = highContrastEnabled ? 'Disable' : 'Enable';
  });

  // Font size controls
  decreaseFontBtn.addEventListener('click', () => {
    if (fontSize > 80) fontSize -= 10;
    document.body.style.fontSize = fontSize + '%';
    fontSizeDisplay.textContent = fontSize + '%';
  });

  increaseFontBtn.addEventListener('click', () => {
    if (fontSize < 150) fontSize += 10;
    document.body.style.fontSize = fontSize + '%';
    fontSizeDisplay.textContent = fontSize + '%';
  });
});

// ...existing code...

// Navigation functionality
function initNavigation() {
    const mobileNav = document.getElementById('mobile-nav');
    const menuIcon = document.getElementById('menu-icon');
    const closeIcon = document.getElementById('close-icon');

    // Open mobile nav
    menuIcon.addEventListener('click', function() {
        mobileNav.classList.add('open');
        menuIcon.style.display = 'none';
        closeIcon.style.display = 'block';
        lucide.createIcons();
    });

    // Close mobile nav
    closeIcon.addEventListener('click', function() {
        mobileNav.classList.remove('open');
        menuIcon.style.display = 'block';
        closeIcon.style.display = 'none';
        lucide.createIcons();
    });
    
    // Close mobile menu when clicking on nav links
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-link');
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', function() {
            mobileNav.classList.remove('open');
            menuIcon.style.display = 'block';
            closeIcon.style.display = 'none';
            lucide.createIcons();
        });
    });
    
    // Handle active navigation state
    const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-content');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // Handle page routing
            const page = this.getAttribute('data-page');
            if (page) {
                navigateToPage(page);
            }
        });
    });
}

// Newsletter functionality
function initNewsletter() {
    const newsletterForm = document.getElementById('newsletter-form');
    const emailInput = document.getElementById('newsletter-email');
    const submitBtn = document.getElementById('newsletter-btn');
    const submitText = document.getElementById('newsletter-text');
    const submitIcon = document.getElementById('newsletter-icon');
    
    newsletterForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = emailInput.value.trim();
        if (email) {
            // Simulate subscription
            submitBtn.disabled = true;
            submitText.textContent = 'Subscribed!';
            submitIcon.style.display = 'none';
            
            // Reset form
            emailInput.value = '';
            
            // Reset button after 3 seconds
            setTimeout(() => {
                submitBtn.disabled = false;
                submitText.textContent = 'Subscribe';
                submitIcon.style.display = 'inline';
                lucide.createIcons();
            }, 3000);
        }
    });
}

// Accessibility widget functionality
function initAccessibilityWidget() {
    const accessibilityBtn = document.getElementById('accessibility-btn');
    const accessibilityPanel = document.getElementById('accessibility-panel');
    const closeBtn = document.getElementById('close-accessibility');
    
    // State variables
    let isOpen = false;
    let fontSize = 16;
    let highContrast = false;
    let ttsEnabled = false;
    let animationsPaused = false;
    
    // Toggle panel
    accessibilityBtn.addEventListener('click', function() {
        isOpen = !isOpen;
        accessibilityPanel.classList.toggle('open', isOpen);
        accessibilityBtn.setAttribute('aria-expanded', isOpen);
    });
    
    closeBtn.addEventListener('click', function() {
        isOpen = false;
        accessibilityPanel.classList.remove('open');
        accessibilityBtn.setAttribute('aria-expanded', false);
    });
    
    // Text-to-Speech functionality
    const ttsBtn = document.getElementById('tts-btn');
    ttsBtn.addEventListener('click', function() {
        if (!ttsEnabled) {
            ttsEnabled = true;
            const selection = window.getSelection().toString();
            if (selection) {
                const utterance = new SpeechSynthesisUtterance(selection);
                speechSynthesis.speak(utterance);
                ttsBtn.textContent = 'Stop';
                ttsBtn.classList.add('active');
                
                utterance.onend = function() {
                    ttsEnabled = false;
                    ttsBtn.textContent = 'Start';
                    ttsBtn.classList.remove('active');
                };
            } else {
                alert('Please select text to hear it read aloud');
                ttsEnabled = false;
            }
        } else {
            speechSynthesis.cancel();
            ttsEnabled = false;
            ttsBtn.textContent = 'Start';
            ttsBtn.classList.remove('active');
        }
    });
    
    // Font size controls
    const fontDecrease = document.getElementById('font-decrease');
    const fontIncrease = document.getElementById('font-increase');
    const fontSizeDisplay = document.getElementById('font-size-display');
    
    fontDecrease.addEventListener('click', function() {
        fontSize = Math.max(fontSize - 2, 12);
        document.documentElement.style.fontSize = fontSize + 'px';
        fontSizeDisplay.textContent = fontSize + 'px';
    });
    
    fontIncrease.addEventListener('click', function() {
        fontSize = Math.min(fontSize + 2, 24);
        document.documentElement.style.fontSize = fontSize + 'px';
        fontSizeDisplay.textContent = fontSize + 'px';
    });
    
    // High contrast toggle
    const contrastBtn = document.getElementById('contrast-btn');
    contrastBtn.addEventListener('click', function() {
        highContrast = !highContrast;
        document.body.classList.toggle('high-contrast', highContrast);
        contrastBtn.textContent = highContrast ? 'On' : 'Off';
        contrastBtn.classList.toggle('active', highContrast);
    });
    
    // Animation pause toggle
    const animationsBtn = document.getElementById('animations-btn');
    animationsBtn.addEventListener('click', function() {
        animationsPaused = !animationsPaused;
        document.body.classList.toggle('reduce-motion', animationsPaused);
        animationsBtn.textContent = animationsPaused ? 'On' : 'Off';
        animationsBtn.classList.toggle('active', animationsPaused);
    });
    
    // Close panel when clicking outside
    document.addEventListener('click', function(e) {
        if (!accessibilityPanel.contains(e.target) && !accessibilityBtn.contains(e.target)) {
            isOpen = false;
            accessibilityPanel.classList.remove('open');
            accessibilityBtn.setAttribute('aria-expanded', false);
        }
    });
}



// Page routing functionality
function initPageRouting() {
    // Handle all navigation links
    const allLinks = document.querySelectorAll('[data-page]');
    allLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const page = this.getAttribute('data-page');
            if (page) {
                navigateToPage(page);
            }
        });
    });
}

function navigateToPage(page) {
    console.log('Navigating to:', page);
    
    // In a real implementation, you would handle routing here
    // For this demo, we'll just show the appropriate content
    switch(page) {
        case 'home':
            // Already on home page
            break;
        case 'moves':
            showMockPage('Moves', 'Professional moving services for your home or office.');
            break;
        case 'storage':
            showMockPage('Storage', 'Secure storage solutions with 24/7 access.');
            break;
        case 'pricing':
            showMockPage('Pricing', 'Transparent pricing for all our services.');
            break;
        case 'track':
            showMockPage('Track', 'Track your shipment in real-time.');
            break;
        case 'about':
            showMockPage('About', 'Learn more about OptiMove Smartlogistics AI.');
            break;
        case 'contact':
            showMockPage('Contact', 'Get in touch with our team.');
            break;
        case 'login':
            showMockPage('Login', 'Access your account dashboard.');
            break;
        default:
            console.log('Unknown page:', page);
    }
}

function showMockPage(title, description) {
    // Create a simple mock page overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        backdrop-filter: blur(8px);
    `;
    
    const content = document.createElement('div');
    content.style.cssText = `
        text-align: center;
        padding: 2rem;
        background: white;
        color: black;
        border-radius: 1rem;
        max-width: 500px;
        margin: 1rem;
    `;
    
    content.innerHTML = `
        <h2 style="margin-bottom: 1rem; font-family: 'Poppins', sans-serif;">${title}</h2>
        <p style="margin-bottom: 2rem; color: #666;">${description}</p>
        <button onclick="this.closest('[style*=\"position: fixed\"]').remove()" 
                style="padding: 0.5rem 1rem; background: hsl(220, 70%, 50%); color: white; border: none; border-radius: 0.5rem; cursor: pointer;">
            Close
        </button>
    `;
    
    overlay.appendChild(content);
    document.body.appendChild(overlay);
    
    // Auto-close after 3 seconds
    setTimeout(() => {
        if (overlay.parentNode) {
            overlay.remove();
        }
    }, 3000);
}

// Smooth scrolling for anchor links
document.addEventListener('click', function(e) {
    if (e.target.tagName === 'A' && e.target.getAttribute('href') && e.target.getAttribute('href').startsWith('#')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
});

// Handle form submissions
document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.id !== 'newsletter-form') {
        e.preventDefault();
        console.log('Form submitted:', form.id || 'unnamed form');
        // Handle other forms here
    }
});

// Initialize animations on scroll
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.service-card, .stat-card, .trust-item');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// Initialize scroll animations when page loads
window.addEventListener('load', initScrollAnimations);

// Handle window resize for responsive behavior
window.addEventListener('resize', function() {
    // Close mobile menu if window becomes large
    if (window.innerWidth >= 768) {
        const mobileNav = document.getElementById('mobile-nav');
        const menuIcon = document.getElementById('menu-icon');
        const closeIcon = document.getElementById('close-icon');
        
        mobileNav.classList.remove('open');
        menuIcon.style.display = 'block';
        closeIcon.style.display = 'none';
    }
});

// Performance optimization: Lazy load images
function initLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                observer.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Select all footer links that point to service cards
const footerLinks = document.querySelectorAll('.footer-links a');
const serviceCards = document.querySelectorAll('.service-card');

footerLinks.forEach(link => {
  link.addEventListener("click", function(e) {
    e.preventDefault();

    // Remove highlight from all cards first
    serviceCards.forEach(card => card.classList.remove("highlight"));

    // Find target section (card)
    const targetId = this.getAttribute("href");
    const targetCard = document.querySelector(targetId);

    if (targetCard) {
      // Smooth scroll to target card
      targetCard.scrollIntoView({ behavior: "smooth", block: "center" });

      // Add highlight to clicked card
      targetCard.classList.add("highlight");

      // Optional: remove highlight after a few seconds
      setTimeout(() => {
        targetCard.classList.remove("highlight");
      }, 4000); // highlight stays 4 seconds
    }
  });
});


// Error handling
window.addEventListener('error', function(e) {
    console.error('Error occurred:', e.error);
    // In production, you might want to send this to an error tracking service
});

// Service worker registration (for future PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Service worker registration would go here
        console.log('Service worker support detected');
    });
}

  const volumeInput = document.getElementById('volume');
const volumeDisplay = document.getElementById('volume-display');
const priceDisplay = document.getElementById('price');


volumeInput.addEventListener('input', () => {
const volume = volumeInput.value;
volumeDisplay.textContent = `${volume} m³`;
// Example pricing: base 2000 per m³
const price = volume * 1000;
priceDisplay.textContent = `KES ${price.toLocaleString()}`;
});

 const hamburgerBtn = document.getElementById('hamburgerBtn');
  const navMenu = document.getElementById('navMenu');

  hamburgerBtn.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburgerBtn.classList.toggle('active'); // toggle X animation
  });
  
  const quotes=document.getElementById('btn-log');
  quotes.addEventListener('click',()=>{
    window.location.href="new.html";
  });
    const freequotes=document.getElementById('free-btn');
    freequotes.addEventListener('click',()=>{
      window.location.href="new.html";
    });

    function toggleDetails(event, element) {
    event.preventDefault();
    const details = element.nextElementSibling;

    if (details.classList.contains("open")) {
      details.classList.remove("open");
      element.innerHTML = 'Learn More <i class="fas fa-arrow-right"></i>';
    } else {
      details.classList.add("open");
      element.innerHTML = 'Show Less <i class="fas fa-arrow-up"></i>';
    }
  }

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener("click", function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    }
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const modal = document.getElementById('aboutusmodal');
  if (!modal) return;

  const openLinks = document.querySelectorAll('a[href="#aboutusmodal"]');
  const closeBtn  = modal.querySelector('.close-btn');

  const openModal = () => {
    modal.classList.add('open');
    document.body.classList.add('modal-open');
    // optional: move focus into modal for accessibility
    (closeBtn || modal).focus?.();
  };

  const closeModal = () => {
    modal.classList.remove('open');
    document.body.classList.remove('modal-open');
    // optional: clear hash so back button behaves nicely
    if (location.hash === '#aboutusmodal') {
      history.replaceState(null, '', ' ');
    }
  };

  // Open on footer/nav click
  openLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      openModal();
    });
  });

  // Close with X
  if (closeBtn) {
    closeBtn.addEventListener('click', closeModal);
  }

  // Close when clicking outside the modal box
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Close with ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeModal();
    }
  });

  // If page loads with #aboutusmodal in the URL, open it
  if (location.hash === '#aboutusmodal') {
    openModal();
  }
});

